package com.example.trainclimb;

import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ActionResult;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.*;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@Mod(modid = "trainclimb", name = "Train Climb", version = "1.0",
     dependencies = "required-after:immersiverailroading")
@Mod.EventBusSubscriber
public class TrainClimb {
    public static SimpleNetworkWrapper NET;
    public static Item GLOVES = new GloveItem();
    public static Item SPEEDO = new Item().setRegistryName("trainclimb", "speedometer")
            .setUnlocalizedName("trainclimb.speedometer").setCreativeTab(CreativeTabs.TOOLS).setMaxStackSize(1);
    static float clientFrac = 0;

    @EventHandler
    public void pre(FMLPreInitializationEvent e) {
        NET = NetworkRegistry.INSTANCE.newSimpleChannel("trainclimb");
        NET.registerMessage(GripMsg.H.class, GripMsg.class, 0, Side.CLIENT);
    }

    @SubscribeEvent
    public static void items(RegistryEvent.Register<Item> e) {
        e.getRegistry().registerAll(GLOVES, SPEEDO);
    }

    @SubscribeEvent
    @SideOnly(Side.CLIENT)
    public static void models(ModelRegistryEvent e) {
        for (Item i : new Item[]{GLOVES, SPEEDO})
            ModelLoader.setCustomModelResourceLocation(i, 0,
                new ModelResourceLocation(i.getRegistryName(), "inventory"));
    }

    public static class GloveItem extends Item {
        public GloveItem() {
            setRegistryName("trainclimb", "grip_gloves");
            setUnlocalizedName("trainclimb.grip_gloves");
            setCreativeTab(CreativeTabs.TOOLS);
            setMaxStackSize(1);
        }
        @Override
        public ActionResult<ItemStack> onItemRightClick(World w, EntityPlayer p, EnumHand h) {
            ItemStack s = p.getHeldItem(h);
            NBTTagCompound d = p.getEntityData();
            if (!d.getBoolean("tc_gloves")) {
                d.setBoolean("tc_gloves", true);
                if (!w.isRemote) p.sendStatusMessage(new TextComponentString("Перчатки надеты: хват +30%"), true);
                return new ActionResult<>(EnumActionResult.SUCCESS, ItemStack.EMPTY);
            }
            return new ActionResult<>(EnumActionResult.PASS, s);
        }
    }

    static boolean isTrain(Entity e) {
        if (e.getClass().getName().contains("immersiverailroading")) return true;
        ResourceLocation id = EntityList.getKey(e);
        return id != null && id.getResourceDomain().contains("immersiverailroading");
    }

    static Entity findTrain(EntityPlayer p) {
        AxisAlignedBB pb = p.getEntityBoundingBox();
        for (Entity e : p.world.getEntitiesWithinAABBExcludingEntity(p, pb.grow(2))) {
            if (!isTrain(e)) continue;
            AxisAlignedBB tb = e.getEntityBoundingBox();
            if (tb.grow(0.35, 0.1, 0.35).intersects(pb) && pb.minY < tb.maxY - 0.4) return e;
        }
        return null;
    }

    @SubscribeEvent
    public static void serverTick(TickEvent.PlayerTickEvent ev) {
        if (ev.phase != TickEvent.Phase.END || ev.side != Side.SERVER) return;
        EntityPlayerMP p = (EntityPlayerMP) ev.player;
        NBTTagCompound d = p.getEntityData();
        float max = d.getBoolean("tc_gloves") ? 130f : 100f;
        float g = d.getFloat("tc_grip");
        float old = g;
        if (p.isSneaking() && !p.capabilities.isCreativeMode && findTrain(p) != null) {
            g += 0.15f;
            if (g >= max) {
                d.setFloat("tc_grip", 0);
                NET.sendTo(new GripMsg(0), p);
                p.attackEntityFrom(new DamageSource("trainGrip").setDamageBypassesArmor(), 1000f);
                return;
            }
        } else {
            g = Math.max(0, g - 0.5f);
        }
        d.setFloat("tc_grip", g);
        if (g != old) NET.sendTo(new GripMsg(g / max), p);
    }

    static int climb = 0;

    @SubscribeEvent
    @SideOnly(Side.CLIENT)
    public static void input(InputUpdateEvent ev) {
        EntityPlayer p = ev.getEntityPlayer();
        if (p.isSneaking() && findTrain(p) != null) {
            climb = ev.getMovementInput().forwardKeyDown ? 1 : ev.getMovementInput().backKeyDown ? -1 : 0;
            ev.getMovementInput().moveForward = 0;
            ev.getMovementInput().moveStrafe = 0;
            ev.getMovementInput().jump = false;
        } else climb = 0;
    }

    @SubscribeEvent
    @SideOnly(Side.CLIENT)
    public static void clientTick(TickEvent.ClientTickEvent ev) {
        EntityPlayer p = Minecraft.getMinecraft().player;
        if (ev.phase != TickEvent.Phase.END || p == null || !p.isSneaking()) return;
        Entity t = findTrain(p);
        if (t == null) return;
        p.motionX = t.posX - t.prevPosX;
        p.motionZ = t.posZ - t.prevPosZ;
        p.motionY = climb > 0 ? 0.12 : climb < 0 ? -0.12 : (t.posY - t.prevPosY);
        p.fallDistance = 0;
    }

    @SubscribeEvent
    @SideOnly(Side.CLIENT)
    public static void hud(RenderGameOverlayEvent.Post ev) {
        if (ev.getType() != RenderGameOverlayEvent.ElementType.ALL) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null) return;
        ScaledResolution r = ev.getResolution();
        int w = r.getScaledWidth(), h = r.getScaledHeight();
        if (clientFrac > 0.001f) {
            int x = w / 2 - 50, y = h - 62;
            Gui.drawRect(x - 1, y - 1, x + 101, y + 7, 0xAA000000);
            int red = (int) (255 * clientFrac), green = (int) (255 * (1 - clientFrac));
            Gui.drawRect(x, y, x + (int) (100 * clientFrac), y + 6, 0xFF000000 | (red << 16) | (green << 8));
            mc.fontRenderer.drawStringWithShadow("Хват", x, y - 10, 0xFFFFFF);
        }
        boolean holds = mc.player.getHeldItemMainhand().getItem() == SPEEDO
                     || mc.player.getHeldItemOffhand().getItem() == SPEEDO;
        if (holds) {
            double dx = mc.player.posX - mc.player.prevPosX, dz = mc.player.posZ - mc.player.prevPosZ;
            int kmh = (int) Math.round(Math.sqrt(dx * dx + dz * dz) * 72.0);
            String s = kmh + " км/ч";
            mc.fontRenderer.drawStringWithShadow(s, (w - mc.fontRenderer.getStringWidth(s)) / 2f, h - 48, 0xFFFF55);
        }
    }

    public static class GripMsg implements IMessage {
        float frac;
        public GripMsg() {}
        public GripMsg(float f) { frac = f; }
        public void fromBytes(ByteBuf b) { frac = b.readFloat(); }
        public void toBytes(ByteBuf b) { b.writeFloat(frac); }
        public static class H implements IMessageHandler<GripMsg, IMessage> {
            public IMessage onMessage(GripMsg m, MessageContext c) { clientFrac = m.frac; return null; }
        }
    }
}
